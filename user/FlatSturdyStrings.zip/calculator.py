
xString = input("Enter a number: ")
x = int(xString)
yString = input("Enter a second number: ")
y = int(yString)
print('', x, ' + ', y, ' = ',x+y, '.', sep='')