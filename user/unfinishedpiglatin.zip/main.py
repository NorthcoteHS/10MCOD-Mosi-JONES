# pig latin translator  
consonant = 'B' or 'C' or 'D' or 'F' or 'G' or 'H' or ' J' or 'K' or 'L' or 'M' or 'N' or 'P' or 'Q' or 'R' or 'S' or 'T' or 'V' or 'W' or 'X' or 'Y' or 'Z'
pig = 'ay'

print "Type a word"
if word(0) = consonant 


